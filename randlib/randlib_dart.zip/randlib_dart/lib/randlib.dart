import "dart:math";
int seed = 0;
int prevSeed = seed;

int newRand(int RANDLIB_MAX){
  while (seed == prevSeed){
    seed = DateTime.now().millisecondsSinceEpoch;
  }
  prevSeed = seed;
  int value =  (8253739 * seed + 2396403) % RANDLIB_MAX;
  return value;
}

int randint(int min, int max, int RANDLIB_MAX){
  if (min > max){
    int max1 = max;
    max = min;
    min = max1;
  }
  int value = min + (newRand(RANDLIB_MAX) % (max - min +1));
  return value;
}

double randfloat(double min, double max, int RANDLIB_MAX){
  if (min > max){
    double max1 = max;
    max = min;
    min = max1;
  }
  double pre, post;
  pre = randint(min.floor(), max.floor()-1, 32767).toDouble();
  post = newRand(32767) / pow(10, (log(RANDLIB_MAX)/ln10).floor()+1);
  return pre + post;
}

bool randbool(){
  return randint(0,1,32767) == 1;
}

String randchar(bool excludeWhitespaces){
  int ascii_code=0;
  var whitespaces = [9, 10, 32];
  if (!excludeWhitespaces && randint(0,6,32767) == 0){
    ascii_code = ascii_code = whitespaces[randint(0,2,32767)];
  }
  else{
    ascii_code = randint(33,126,32767);
  }
  return String.fromCharCode(ascii_code);
  
}

String randstring(int length, bool excludeWhitespaces){
  String text = "";
  for (int i = 0; i < length; i++){
    text += randchar(excludeWhitespaces);
  }
  return text;
}