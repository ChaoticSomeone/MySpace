#ifndef RANDLIB_RANDLIB_H
#define RANDLIB_RANDLIB_H

#include <math.h>
#include <time.h>


unsigned long long RANDLIB_MAX = 32767;
int seed = 0;
clock_t t1, t2;

void randinit(void){
    t1 = clock();
}

void set_RANDLIB_MAX(unsigned long long value){
	RANDLIB_MAX = value;
}

int newRand(void){
	unsigned int value;
	t2 = clock();
	seed = t2 - t1;
	value = (8253739 * seed + 2396403);
	value = value % RANDLIB_MAX;
	return value;
}

int randint(int min, int max){
    if (max < min){
        max, min = min, max;
    }
    unsigned long long r = newRand();
    return min + (r % (max - min + 1));
}

short randshort(short min, short max){
    if (max < min){
        max, min = min, max;
    }
    unsigned long long r = newRand();
    return min + (r % (max - min + 1));
}

long randlong(long min, long max){
    if (max < min){
        max, min = min, max;
    }
    return min + (newRand() % (max - min + 1));
}

float randfloat(float min, float max){
    if (max < min){
        max, min = min, max;
    }
    long long pre;
    long double post;
    unsigned long long r = (float) newRand();
    pre = randint((int) min, (int) max-1);
    post =  r / pow(10,(float) log10(RANDLIB_MAX));
    return (float) pre + (float) post;
}
double randdouble(double min, double max){
    if (max < min){
        max, min = min, max;
    }
    long long pre;
    long double post;
    unsigned long long r = (float) newRand();
    pre = randint((int) min, (int) max-1);
    post = (double) newRand() / pow(10,(double) log10(RANDLIB_MAX));
    return pre + post;
}

int randbool(){
    return 1+newRand()%2 == 1 ? 0 : 1;
}

char randchar(int excludeWhitespaces)
{
    char value;
    if (excludeWhitespaces)
    {
        char symbols[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '!', '\"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/', ':', ';', '<', '=', '>', '?', '@', '[', '\\', ']', '^', '_', '`', '{', '|', '}', '~'};
        value = symbols[randint(0, sizeof(symbols) - 1)];
    }
    else
    {
        char symbols[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '!', '\"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/', ':', ';', '<', '=', '>', '?', '@', '[', '\\', ']', '^', '_', '`', '{', '|', '}', '~', ' ', '\n', '\t'};
        value = symbols[randint(0, sizeof(symbols) - 1)];
    }
    return value;
}

#endif //RANDLIB_RANDLIB_H
