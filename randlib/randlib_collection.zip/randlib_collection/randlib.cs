﻿using System;
using System.Linq;

namespace Randlib
{

	public static class randlib
	{
		static private ulong RANDLIB_MAX = 32767;
		static private ulong t1, t2;
		
		public static void randinit(){
			t1 = (ulong)DateTime.Now.Ticks;
		}
		
		public static void set_RANDLIB_MAX(ulong value){
			RANDLIB_MAX = value;
		}
		
		private static int newRand(){
			uint value;
			t2 = (ulong)DateTime.Now.Ticks;
			ulong seed = (ulong)(t2 - t1);
			value = (uint)((ulong)(8253738 * seed + 2396403) % RANDLIB_MAX);
			return (int)value;
		}
		
		public static int randint(int min, int max){
			if (min > max){
				(min, max) = (max, min);
			}
			return min + (newRand() % (max - min + 1));
		}
		
		public static short randshort(short min, short max){
			if (min > max){
				(min, max) = (max, min);
			}
			return (short)((int)min + (newRand() % (int)(max - min + 1)));
		}
		
		public static long randlong(long min, long max){
			if (min > max){
				(min, max) = (max, min);
			}
			return (long)((int)min +(newRand() % (int)(max - min +1)));
		}
		
		public static float randfloat(float min, float max){
			if (min > max){
				(min, max) = (max, min);
			}
			long pre;
			float post;
			pre = randint((int)min, (int)(max-1));
			post = (float)newRand() / (float)Math.Pow(10, (float) Math.Log10(RANDLIB_MAX));
			return (float)post + (float)pre;
		}
		
		public static double randdouble(double min, double max){
			if (min > max){
				(min, max) = (max, min);
			}
			long pre;
			double post;
			pre = randint((int)min, (int)(max-1));
			post = (double)newRand() / (double)Math.Pow(10, (double)Math.Log10(RANDLIB_MAX));
			return (double)post + (double)pre;
		}
		
		public static bool randbool(){
			return randint(0,1) == 1 ? true : false;
		}
		
		public static char randchar(bool excludeWhitespaces){
			char[] whitespaces = {' ', '\t', '\n'};
			if (excludeWhitespaces){
				return (char)randint(33, 126);
			}
			else{
				return randint(0,16) != 0 ? (char)randint(33, 126) : whitespaces[randint(0, whitespaces.Length-1)];
			}
		}
		
		public static string randstring(uint length, bool excludeWhitespaces){
			string text = "";
			for (int i = 0; i < length; i++){
				text += randchar(excludeWhitespaces);
			}
			return text;
		}
		
		
	}
}