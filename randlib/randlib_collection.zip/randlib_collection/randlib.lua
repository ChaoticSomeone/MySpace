RANDLIB_MAX = 32767
INT_LIMIT = 2147483657
seed = 0
prevSeed = seed

local Randlib = {}

function newRand()
	repeat
		seed = os.time()
	until seed ~= prevSeed
	prevSeed = seed
	return ((8253739 * seed + 2396403) % INT_LIMIT) % RANDLIB_MAX
end

function Randlib.set_RANDLIB_MAX(value)
	RANDLIB_MAX = value
end

function Randlib.randint(min, max)
	if min > max then
		max1 = max
		max = min
		min = max1
	end
	min = math.floor(min+0.5)
	max = math.floor(max+0.5)
	local value = min + (newRand()%(max - min +1))
	return value
end

function Randlib.randfloat(min, max)
	if min > max then
		max1 = max
		max = min
		min = max1
	end
	pre = Randlib.randint(math.floor(min),math.floor(max)-1)
	post = newRand()/10^ math.floor(math.log(RANDLIB_MAX, 10))
	return pre + post
end

function Randlib.randchar(excludeWhitespaces)
	local c
	local whitespaces ={' ', '\t', '\n'}
	if not excludeWhitespaces then
		if Randlib.randint(0,6) == 6 then
			c = whitespaces[Randlib.randint(1,3)]
		else
			c = string.char(Randlib.randint(33,126))
		end
	else
		c = string.char(Randlib.randint(33,126))
	end
	return c
end

function Randlib.randstring(length, excludeWhitespaces)
	local text = ""
	for i=0, length-1 do
		repeat
			c = Randlib.randchar(excludeWhitespaces)
		until c ~= nil
		text = text .. c
	end
	return text
end

return Randlib 