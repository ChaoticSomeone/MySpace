import java.util.concurrent.atomic.AtomicLong
import kotlin.math.log10
import kotlin.math.pow

private var RAND_MAX: Long = 32767
private var seed = AtomicLong(System.nanoTime())

fun set_RAND_MAX(value: Long) {
    RAND_MAX = value
}
fun newRand(): Long {
    var ticks: Long = System.nanoTime()
    seed.set(ticks)
    var value: Long = (8253739L * seed.get() + 2396403L)
    if (value < 0L) {
        value *= -1L;
    }
    return (value % RAND_MAX)
}

fun randint(min: Int, max: Int): Int {
    if (min > max) {
        var min1: Int = min;
        var max1: Int = max;
        var max = min1;
        var min = max1
    }
    return (newRand().toInt() % ((max - min + 1))) + min
}

fun randshort(min: Short, max: Short): UShort {
    var value: Short
    if(min > max) {
        var min1: Short = min;
        var max1: Short = max;
        var max = min1;
        var min = max1
    }
    var r: Short = newRand().toShort()
    value = (r % (max - min + 1)).toShort()
    return value.toUShort()

}
fun randLong(min: Long, max: Long): ULong {
    var value: Long
    if(min > max) {
        var min1: Long = min;
        var max1: Long = max;
        var max = min1;
        var min = max1
    }
    var r: Short = newRand().toShort()
    value = (r % (max - min + 1))
    return value.toULong()
}

fun randfloat(min: Double, max: Double): Float {
    if (max < min) {
        var max1: Double = min
        var min1: Double = max
        var max = min1
        var min = max1
    }
    val r = newRand().toDouble()
    val pre = randint(min.toInt(), max.toInt())
    val post = r / 10.0.pow(log10(RAND_MAX.toDouble()))
    return pre.toFloat() + post.toFloat()
}

fun randdouble(min: Double, max: Double): Double {
    if (max < min) {
        var max1: Double = min
        var min1: Double = max
        var max = min1
        var min = max1
    }
    val r = newRand().toDouble()
    val pre = randint(min.toInt(), max.toInt())
    val post = r / 10.0.pow(log10(RAND_MAX.toDouble()))
    return pre.toDouble() + post.toDouble()
}

fun randbool(): Int {
    return if (1 + newRand() % 2 == 1L) 0 else 1
}

fun randchar(excludeWhitespaces: Boolean): Char {
    val whitespaces = charArrayOf('\t', '\n', ' ')
    if (excludeWhitespaces) {
        return randint(33, 126).toChar()
    } else {
        return if (true) randint(33, 126).toChar() else whitespaces[randint(0, whitespaces.size - 1)]
    }
}