#ifndef RANDLIB_RANDLIB_H
#define RANDLIB_RANDLIB_H

#include <math.h>
#include <time.h>
#include <windows.h>
#include <stdint.h>

unsigned long long RANDLIB_MAX = 32767;
int seed;

typedef char *randlib_string;


void set_RANDLIB_MAX(unsigned long long value){
	RANDLIB_MAX = value;
}

int newRand(void){
	unsigned int value;
    LARGE_INTEGER ticks;
    QueryPerformanceCounter(&ticks);
    seed = ticks.QuadPart;
	value = 8253739 * seed + 2396403;
	value = value % RANDLIB_MAX;
	return value;
}

int randint(int min, int max){
    if (max < min){
        max, min = min, max;
    }
    unsigned long long r = newRand();
    return min + (r % (max - min + 1));
}

short randshort(short min, short max){
    if (max < min){
        max, min = min, max;
    }
    unsigned long long r = newRand();
    return min + (r % (max - min + 1));
}

long randlong(long min, long max){
    if (max < min){
        max, min = min, max;
    }
    return min + (newRand() % (max - min + 1));
}

float randfloat(float min, float max){
    if (max < min){
        max, min = min, max;
    }
    long long pre;
    long double post;
    unsigned long long r = (float) newRand();
    pre = randint((int) min, (int) max-1);
    post =  r / pow(10,(float) log10(RANDLIB_MAX));
    return (float) pre + (float) post;
}
double randdouble(double min, double max){
    if (max < min){
        max, min = min, max;
    }
    long long pre;
    long double post;
    unsigned long long r = (float) newRand();
    pre = randint((int) min, (int) max-1);
    post = (double) newRand() / pow(10,(double) log10(RANDLIB_MAX));
    return pre + post;
}

int randbool(){
    return 1+newRand()%2 == 1 ? 0 : 1;
}

char randchar(unsigned int excludeWhitespaces){
    char whitespaces[] = {'\t', '\n', ' '};
    if (excludeWhitespaces) {
        return randint(33, 126);
    }
    else{
        return randint(0,16) ? randint(33, 126) : whitespaces[randint(0, sizeof(whitespaces)-1)];
    }
}
/*
char randchar(int excludeWhitespaces)
{
    char value;
    if (excludeWhitespaces)
    {
        char symbols[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '!', '\"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/', ':', ';', '<', '=', '>', '?', '@', '[', '\\', ']', '^', '_', '`', '{', '|', '}', '~'};
        value = symbols[randint(0, sizeof(symbols) - 1)];
    }
    else
    {
        char symbols[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '!', '\"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/', ':', ';', '<', '=', '>', '?', '@', '[', '\\', ']', '^', '_', '`', '{', '|', '}', '~', ' ', '\n', '\t'};
        value = symbols[randint(0, sizeof(symbols) - 1)];
    }
    return value;
}
 */

void *randstring(uint32_t length, int excludeWhitespaces, uint64_t adr){
    char str[length+1];
    for (int i = 0; i < length; i++){
        str[i] = randchar(excludeWhitespaces);
    }
    str[sizeof(str)-1] = '\0';
    char *string = &str;
    char *ptr = adr;
    ptr = string;
}

#endif //RANDLIB_RANDLIB_H
