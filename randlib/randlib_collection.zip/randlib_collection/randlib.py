import time as t
import math

__RANDLIB_MAX = 32767
__INT_LIMIT = (2**31)-1
seed = 0
t1, t2 = 0,0
	
def randinit():
	t1 = t.monotonic_ns()

def set_RANDLIB_MAX(value):
	__RANDLIB_MAX = int(round(value))

def newRand():
	t2 = t.monotonic_ns()
	seed = t2 - t1
	value = (8253739 * seed + 2396403) % __INT_LIMIT
	return value % __RANDLIB_MAX

def randint(min, max):
	min = int(round(min))
	max = int(round(max))
	if min > max:
		min, max = max, min
	return min + (newRand() % (max - min +1))

def randfloat(min, max, decimals=0):
	if min > max:
		min, max = max, min
	pre, post = randint(min, max-1), newRand() / 10**math.log10(__RANDLIB_MAX)
	if decimals > 0:
		post = round(post,decimals)
	return pre + post

def randbool():
	return True if randint(0,1) == 1 else False

def randchar(excludeWhitespaces):
	chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890@#€&_-()=%*':/!?+.,$~<>^[]{}`;\|¦"
	if not excludeWhitespaces:
		chars += " \n\t"
	return chars[randint(0,len(chars)-1)]

def randstring(length, excludeWhitespaces):
	length *= -1 if length < 0 else 1
	text = ""
	for _ in range(length):
		text += randchar(excludeWhitespaces)
	return text